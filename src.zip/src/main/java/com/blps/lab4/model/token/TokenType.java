package com.blps.lab4.model.token;

public enum TokenType {
    BEARER
}
