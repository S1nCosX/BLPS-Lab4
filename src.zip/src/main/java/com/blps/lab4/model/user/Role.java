package com.blps.lab4.model.user;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ROLE_USER,
    ROLE_MODERATOR,
    ROLE_HR
}
