package com.blps.lab4.model.common;

public enum WorkMode {
    FULL_TIME,
    PART_TIME,
    VOLUNTEERING,
    FLEXIBLE_HOURS
}
