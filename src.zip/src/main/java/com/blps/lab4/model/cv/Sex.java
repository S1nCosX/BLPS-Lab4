package com.blps.lab4.model.cv;

public enum Sex {
    MALE,
    FEMALE
}
