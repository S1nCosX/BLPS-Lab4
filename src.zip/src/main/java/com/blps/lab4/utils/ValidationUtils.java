package com.blps.lab4.utils;

public class ValidationUtils {
    public static String validatePhoneNumber(String phoneNumber) {
        return phoneNumber;
    }
}
