package com.blps.lab4.model.common;

public enum Status {
    WAITING,
    ASSIGNED,
    APPROVED
}
